﻿int[] array = { 7, 0, -4, 3, 1, -2, 5 };
int temp, min;
for (int i = 0; i < array.Length - 1; i++)
{
    min = i;
    for (int j = i + 1; j < array.Length; j++)
    {
        if (array[j] < array[min])
        {
            min = j;
        }
    }
    if (min != 0)
    { 
    temp = array[min];
    array[min] = array[i];
    array[i] = temp;
    Console.Write("\nШаг" + (i + 1) + " : ");
    PrintArray(array);
    }
}

static void PrintArray(int[] array)
{
    foreach (var item in array)
    {
        Console.Write(item + " ");
    }
}