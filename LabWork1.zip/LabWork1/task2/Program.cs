﻿int[] numbers = { 7, 0, -4, 3, 1, -2, 5 };
int n = 7;
for (int i = 0; i<n;i++)
{
    for(int j = 0; j<n-i-1;++j)
    {
        if (numbers[j] > numbers[j + 1])
           (numbers[j], numbers[j + 1]) = (numbers[j + 1], numbers[j]);
        Console.Write(numbers[j] + " ");
    }

}
