﻿public class Employee : IComparable
{
    public string FullName { get; set; }
    public string Position { get; set; }
    public decimal Salary { get; set; }

    public Employee(string fullName, string position, decimal salary)
    {
        FullName = fullName;
        Position = position;
        Salary = salary;
    }

    public int CompareTo(object obj)
    {
        if (obj == null) return 1;

        Employee otherEmployee = obj as Employee;
        if (otherEmployee != null)
            return this.Salary.CompareTo(otherEmployee.Salary);
        else
            throw new ArgumentException("Object не является Employee");
    }

    public override string ToString()
    {
        return $"ФИО: {FullName}, Должность: {Position}, Зарплата: {Salary}";
    }
}
