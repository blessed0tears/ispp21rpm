﻿namespace LabWork10
{
    internal class Program
    {
        static void Main()
        {
            Train[] trains = new Train[]
            {
                new Train(1, "A", 120),
                new Train(2, "B", 90),
                new Train(3, "C", 150),
                new Train(4, "D", 80),
                new Train(5, "E", 100),
            };

            Console.WriteLine("Исходный массив: ");
            PrintTrains(trains);

            Array.Sort(trains);

            Console.WriteLine("\nОтсортированный массив: ");
            PrintTrains(trains);

            Array.Sort(trains, (x, y) => x.CompareToDescending(y));
            Console.WriteLine("\nОтсортированный массив: ");
            PrintTrains(trains);
        }
        static void PrintTrains(Train[] trains)
        {
            foreach (var train in trains)
            {
                Console.WriteLine($"Поезд №{train.Number} направляется в {train.Destination} с {train.Seats} свободными местами");
            }
        }
    }
}