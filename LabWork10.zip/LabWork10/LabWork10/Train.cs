﻿namespace LabWork10
{
    class Train : IComparable , IComparable<Train>
    {
        public int Number;
        public string Destination;
        public int Seats;

        public Train(int number, string destination, int seats)
        {
            Number = number;
            Destination = destination;
            Seats = seats;
        }
        public int CompareTo(object obj)
        {
            if (obj == null) return 1;

            Train other = obj as Train;
            if (other != null)
            {
                return this.Seats.CompareTo(other.Seats);
            }
            else
            {
                throw new ArgumentException("объект не поезд");
            }
        }
        public int CompareTo(Train other)
        {
            if (other == null) return 1;

            return this.Seats.CompareTo(other.Seats);
        }
        public int CompareToDescending(Train other)
        {
            if (other == null) return -1;

            return other.Seats.CompareTo(this.Seats);
        }
    }
}