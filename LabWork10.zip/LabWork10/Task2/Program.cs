﻿namespace LabWork10
{
    using System;

    class Program
    {
        static void Main()
        {
            Employee[] employees = {
            new Employee("Чернов Иван Миронович", "Менеджер", 60000),
            new Employee("Константинов Георгий Романович", "Раработчик", 75000),
            new Employee("Козлов Даниил Константинович", "Дизайнер", 50000)
        };

            Console.WriteLine("Исходый массив:");
            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }

            Array.Sort(employees);

            Console.WriteLine("\nОтсортированный массив:");
            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }
        }
    }

}
