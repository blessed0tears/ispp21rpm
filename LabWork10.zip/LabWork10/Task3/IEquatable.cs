﻿public class Employee : IEquatable<Employee>
{
    public string FullName { get; set; }
    public string Position { get; set; }
    public decimal Salary { get; set; }

    public Employee(string fullName, string position, decimal salary)
    {
        FullName = fullName;
        Position = position;
        Salary = salary;
    }

    public bool Equals(Employee other)
    {
        if (other == null) return false;
        return this.FullName == other.FullName &&
               this.Position == other.Position &&
               this.Salary == other.Salary;
    }

    public override bool Equals(object obj)
    {
        if (obj == null) return false;
        Employee objAsEmployee = obj as Employee;
        if (objAsEmployee == null) return false;
        else return Equals(objAsEmployee);
    }

    public override int GetHashCode()
    {
        return FullName.GetHashCode() ^ Position.GetHashCode() ^ Salary.GetHashCode();
    }

    public override string ToString()
    {
        return $"FullName: {FullName}, Position: {Position}, Salary: {Salary}";
    }
}
