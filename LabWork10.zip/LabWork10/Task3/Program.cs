﻿class Program
{
    static void Main()
    {
        Employee employee1 = new Employee("Чернов Иван Миронович", "Менеджер", 60000);
        Employee employee2 = new Employee("Константинов Георгий Романович", "Раработчик", 75000);

        Console.WriteLine($"employee1 == employee2: {employee1.Equals(employee2)}");

        Employee employee3 = new Employee("Константинов Георгий Романович", "Раработчик", 75000);
        Console.WriteLine($"employee2 == employee3: {employee2.Equals(employee3)}");
    }
}
