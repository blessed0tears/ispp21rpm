﻿namespace Task4
{
    public class Employee : ICloneable
    {
        public string FullName { get; set; }
        public string Position { get; set; }
        public decimal Salary { get; set; }

        public Employee(string fullName, string position, decimal salary)
        {
            FullName = fullName;
            Position = position;
            Salary = salary;
        }

        public object Clone()
        {
            return new Employee(this.FullName, this.Position, this.Salary);
        }

        public override string ToString()
        {
            return $"ФИО: {FullName}, Должность: {Position}, Зарплата: {Salary}";
        }
    }

}
