﻿using Task4;

class Program
{
    static void Main()
    {
        Employee original = new Employee("Гришин Андрей Александрович", "Челюстно-лицевой хирург", 60000);
        Employee clone = (Employee)original.Clone();

        Console.WriteLine("Оригинал:");
        Console.WriteLine(original);

        Console.WriteLine("\nКлонированный:");
        Console.WriteLine(clone);

        clone.Salary = 70000;
        Console.WriteLine("\nПосле модификации клонированного работника:");
        Console.WriteLine("Оригинал:");
        Console.WriteLine(original);
        Console.WriteLine("Клонированный:");
        Console.WriteLine(clone);
    }
}
