﻿using System;
using System.Collections.Generic;

public class DescendingSalaryComparer : IComparer<Employee>
{
    public int Compare(Employee x, Employee y)
    {
        return y.Salary.CompareTo(x.Salary);
    }
}

public class StringComparer : IComparer<Employee>
{
    public int Compare(Employee x, Employee y)
    {
        return string.Compare(x.FullName, y.FullName);
    }
}
