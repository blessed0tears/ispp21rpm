﻿
class Program
{
    static void Main()
    {
        Employee[] employees = {
            new Employee("Иванов Марк Кириллович", "Менеджер", 60000),
            new Employee("Николаева Виктория Филипповна", "Директор", 75000),
            new Employee("Иванова Таисия Ивановна", "Разработчик", 50000)
        };

        Console.WriteLine("Оригинальный массив:");
        foreach (var employee in employees)
        {
            Console.WriteLine(employee);
        }

        Array.Sort(employees, new DescendingSalaryComparer());

        Console.WriteLine("\nОтсортированный массив по убыванию зарплаты:");
        foreach (var employee in employees)
        {
            Console.WriteLine(employee);
        }

        Array.Sort(employees, new StringComparer());

        Console.WriteLine("\nОтсортированный массив по ФИО:");
        foreach (var employee in employees)
        {
            Console.WriteLine(employee);
        }
    }
}
