﻿using System;
using System.Collections.Generic;
class Program
{
    static void Main()
    {
        List<string> Goods = new List<string>();
        Goods.Add("Товар 1");
        Goods.Add("Товар 2");
        Goods.Add("Товар 3");

        Console.WriteLine("Введите количество товаров: ");
        int N = int.Parse(Console.ReadLine());

        for (int i = 0; i < N; i++) 
        {
            Console.WriteLine($"Введите название товара  {i+4}: ");
            string good = Console.ReadLine();
            Goods.Add(good);
        }
        Console.WriteLine("Элементы списка: ");
        for (int i = 0;i < Goods.Count; i++) 
        {
            Console.WriteLine($"{i+1} - {Goods[i]}");
        }
        Dictionary<int, string> dictionary = new Dictionary<int, string>();
        dictionary.Add(1, "Книга 1");
        dictionary.Add(2, "Книга 2");
        dictionary.Add(3, "Книга 3");

        Console.WriteLine("Введите количество элементов: ");
        int A = int.Parse(Console.ReadLine());

        for (int i = 0; i < A; i++)
        {
            Console.WriteLine($"Введите библиотечный номер для книги {i+4}: ");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine($"Введите название книги {number}: ");
            string name = Console.ReadLine();
            dictionary.Add(number, name);
        }
        Console.WriteLine("Содержимое словоря: ");
        foreach (var kvp in dictionary) 
        {
            Console.WriteLine($"{kvp.Key} - {kvp.Value}");
        }
        Console.WriteLine($"Количество элементов в словаре: {dictionary.Count}");
        Console.WriteLine("Введите ключ для поиска: ");
        int userKey = int.Parse(Console.ReadLine()); ;

        if (dictionary.ContainsKey(userKey))
        {
            Console.WriteLine($"Значение по ключу {userKey}: {dictionary[userKey]}");
        }
        else 
        {
            Console.WriteLine($"Ключ {userKey} отсутствует в словаре.");
        }
        Console.WriteLine("Введите значение для подсчёта совпадений: ");
        string userValue = Console.ReadLine();
        int count = 0;
        foreach (var pair in dictionary) 
        {
            if (pair.Key == userKey) 
            {
                count++;
            }
        }
        Console.WriteLine($"Количество совпадений значения {userValue}: {count}");

        Console.WriteLine("Введите ключ для удаления: ");
        int keyToRemove = int.Parse(Console.ReadLine());
        if (dictionary.ContainsKey(keyToRemove))
        {
            dictionary.Remove(keyToRemove);
            Console.WriteLine($"Элемент с ключом {keyToRemove} удалён");
        }
        else
        {
            Console.WriteLine($"Ключ {keyToRemove} отсутствует");
        }
        Console.WriteLine("Содержимое словаря после удаления: ");
        foreach (var pair in dictionary) 
        {
            Console.WriteLine($"Ключ: {pair.Key}, значение {pair.Value}"); 
        }
    }
}