﻿class Program
{
    static void Main()
    {
        Dictionary<int, string> employeePositions = new Dictionary<int, string>();

        employeePositions.Add(101, "Менеджер");
        employeePositions.Add(102, "Инженер");
        employeePositions.Add(103, "Бухгалтер");
        employeePositions.Add(104, "Менеджер");
        employeePositions.Add(105, "Инженер");
        employeePositions.Add(106, "Бухгалтер");
        employeePositions.Add(107, "Менеджер");
        employeePositions.Add(108, "Инженер");
        employeePositions.Add(109, "Бухгалтер");
        employeePositions.Add(110, "Менеджер");
        employeePositions.Add(111, "Инженер");
        employeePositions.Add(112, "Бухгалтер");

        Console.Write("Введите количество дополнительных элементов: ");
        int N = int.Parse(Console.ReadLine());
        for (int i = 0; i < N; i++)
        {
            Console.Write("Введите табельный номер: ");
            int employeeNumber = int.Parse(Console.ReadLine());
            Console.Write("Введите должность: ");
            string position = Console.ReadLine();
            employeePositions.Add(employeeNumber, position);
        }

        Console.WriteLine("Словарь (Табельный номер – Должность):");
        foreach (var item in employeePositions)
        {
            Console.WriteLine($"{item.Key} – {item.Value}");
        }
        Console.WriteLine($"Всего элементов в словаре: {employeePositions.Count}");
    }
}
