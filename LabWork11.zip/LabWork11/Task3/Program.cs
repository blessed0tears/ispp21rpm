﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Dictionary<int, string> employeePositions = new Dictionary<int, string>
        {
            { 101, "Менеджер" },
            { 102, "Инженер" },
            { 103, "Бухгалтер" },
            { 104, "Менеджер" },
            { 105, "Инженер" },
            { 106, "Бухгалтер" },
            { 107, "Менеджер" },
            { 108, "Инженер" },
            { 109, "Бухгалтер" },
            { 110, "Менеджер" },
            { 111, "Инженер" },
            { 112, "Бухгалтер" },
            { 113, "Уборщик" },
            { 114, "Инженер" },
            { 115, "Директор" },
            { 116, "Менеджер" },
            { 117, "Инженер" },
            { 118, "Бухгалтер" }

        };

        Console.Write("Введите табельный номер для поиска: ");
        int searchKey = int.Parse(Console.ReadLine());

        if (employeePositions.ContainsKey(searchKey))
        {
            Console.WriteLine($"Табельный номер {searchKey} соответствует должности: {employeePositions[searchKey]}");
        }
        else
        {
            Console.WriteLine($"Табельный номер {searchKey} не найден.");
        }

        Console.Write("Введите должность для подсчета совпадений: ");
        string searchValue = Console.ReadLine();
        int count = 0;
        foreach (var value in employeePositions.Values)
        {
            if (value == searchValue) count++;
        }
        Console.WriteLine($"Должность '{searchValue}' найдена {count} раз(а) в словаре.");

        Console.Write("Введите табельный номер для удаления: ");
        int deleteKey = int.Parse(Console.ReadLine());
        if (employeePositions.Remove(deleteKey))
        {
            Console.WriteLine($"Табельный номер {deleteKey} успешно удален.");
        }
        else
        {
            Console.WriteLine($"Табельный номер {deleteKey} не найден для удаления.");
        }

        Console.WriteLine("Словарь после удаления:");
        foreach (var item in employeePositions)
        {
            Console.WriteLine($"{item.Key} – {item.Value}");
        }
    }
}
