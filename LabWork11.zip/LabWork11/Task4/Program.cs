﻿class Program
{
    static void Main()
    {
        List<string> birds = new List<string> { "Соловей", "Воробей", "Голубь" };

        birds.Sort((a, b) => b.CompareTo(a)); // Сортировка по убыванию
        Console.Write("Введите количество элементов для вывода из начала списка: ");
        int count = int.Parse(Console.ReadLine());

        Console.WriteLine("Список птиц после сортировки по убыванию:");
        for (int i = 0; i < count && i < birds.Count; i++)
        {
            Console.WriteLine($"{i + 1} – {birds[i]}");
        }
    }
}
