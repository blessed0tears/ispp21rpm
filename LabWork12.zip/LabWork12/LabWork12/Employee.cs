﻿struct Employee
{
    private string fullName;
    private string position;
    private decimal salary;

    public Employee(string fullName, string position, decimal salary)
    {
        this.fullName = fullName;
        this.position = position;
        this.salary = salary;
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"ФИО: {fullName}, Должность: {position}, Зарплата: {salary}");
    }
}
