﻿using System;
using static Trains;

class Trains
{
    public enum Destination
    {
        City1,
        City2,
        City3
    }
    public struct Train
    {
        private int number;
        private Destination destination;
        private int seats;
        private string v1;
        private int v2;
        private Destination city1;

        public Train(int number, Destination destination, int seats)
        {
            this.number = number;
            this.destination = destination;
            this.seats = seats;
        }

        public Train(string v1, int v2, Destination city1) : this()
        {
            this.v1 = v1;
            this.v2 = v2;
            this.city1 = city1;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Номер поезда {number}, свободные места {seats}, место прибытия{destination}");
        }
    }
}
class Program
{
        
        static void Main()
        {
        Train train1 = new Train("123ADD", 100, Destination.City1);

        }
    
}
