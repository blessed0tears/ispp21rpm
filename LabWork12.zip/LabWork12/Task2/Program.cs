﻿class Program
{
    static void Main(string[] args)
    {
        Employee employee1 = new Employee();
        Employee employee2 = new Employee("Иванов Иван Иванович", "Инженер", 50000);

        try
        {
            employee1.FullName = "Петров Петр Петрович";
            employee1.Position = "Менеджер";
            employee1.Salary = 40000;
        }
        catch (ArgumentException e)
        {
            Console.WriteLine(e.Message);
        }

        employee1.DisplayInfo();
        employee2.DisplayInfo();
    }
}
