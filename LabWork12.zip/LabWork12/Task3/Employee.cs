﻿struct Employee
{
    private string fullName;
    private string position;
    private decimal salary;
    private EmploymentType employmentType;

    public Employee(string fullName, string position, decimal salary)
    {
        this.fullName = fullName;
        this.position = position;
        this.salary = salary;
        this.employmentType = EmploymentType.FullTime;
    }

    public string FullName
    {
        get { return fullName; }
        set
        {
            if (!string.IsNullOrWhiteSpace(value))
                fullName = value;
            else
                throw new ArgumentException("ФИО не должно быть пустым.");
        }
    }

    public string Position
    {
        get { return position; }
        set
        {
            if (!string.IsNullOrWhiteSpace(value))
                position = value;
            else
                throw new ArgumentException("Должность не должна быть пустой.");
        }
    }

    public decimal Salary
    {
        get { return salary; }
        set
        {
            if (value >= 0)
                salary = value;
            else
                throw new ArgumentException("Зарплата не должна быть меньше нуля.");
        }
    }

    public EmploymentType EmploymentType
    {
        get { return employmentType; }
        set { employmentType = value; }
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"ФИО: {fullName}, Должность: {position}, Зарплата: {salary}, Тип занятости: {employmentType}");
    }
}
