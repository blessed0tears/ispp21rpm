﻿enum EmploymentType
{
    FullTime,
    PartTime,
    Internship
}
