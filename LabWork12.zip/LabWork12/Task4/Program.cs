﻿class Program
{
    static void Main(string[] args)
    {
        Employee[] employees = new Employee[]
        {
            new Employee("Иванов Иван Иванович", "Инженер", 50000) { EmploymentType = EmploymentType.FullTime },
            new Employee("Петров Петр Петрович", "Менеджер", 40000) { EmploymentType = EmploymentType.PartTime },
            new Employee("Сидоров Сидор Сидорович", "Стажер", 20000) { EmploymentType = EmploymentType.PartTime }
        };

        Console.WriteLine("Работники с частичной занятостью:");
        foreach (var worker in employees)
        {
            if (worker.EmploymentType == EmploymentType.PartTime)
            {
                worker.DisplayInfo();
            }
        }
    }
}
