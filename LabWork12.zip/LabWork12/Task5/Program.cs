﻿record EmployeeRecord(string FullName, string Position, decimal Salary);

class Program
{
    static void Main(string[] args)
    {
        EmployeeRecord employeeRecord1 = new EmployeeRecord("Иванов Иван Иванович", "Инженер", 50000);
        EmployeeRecord employeeRecord2 = new EmployeeRecord("Иванов Иван Иванович", "Инженер", 50000);
        EmployeeRecord employeeRecord3 = new EmployeeRecord("Петров Петр Петрович", "Менеджер", 40000);

        Console.WriteLine(employeeRecord1);
        Console.WriteLine(employeeRecord2);
        Console.WriteLine(employeeRecord3);

        Console.WriteLine($"workerRecord1 == workerRecord2: {employeeRecord1 == employeeRecord2}");
        Console.WriteLine($"workerRecord1 == workerRecord3: {employeeRecord1 == employeeRecord3}");
        Console.WriteLine($"workerRecord1.Equals(workerRecord2): {employeeRecord1.Equals(employeeRecord2)}");
        Console.WriteLine($"workerRecord1.Equals(workerRecord3): {employeeRecord1.Equals(employeeRecord3)}");
    }
}
