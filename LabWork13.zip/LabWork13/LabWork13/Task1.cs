﻿// Количество символов во введенной пользователем строки.
string string1 = Console.ReadLine();
Console.WriteLine($"{string1.Length} символов в строке");

// Количество символов во введенной пользователем строке без учёта пробелов.
string string2 = Console.ReadLine();
int symbolCountWithoutSpace = 0;

foreach (char count in string2)
{
    if (!Char.IsWhiteSpace(count))
    {
        symbolCountWithoutSpace++;
    }
}
Console.WriteLine($"{symbolCountWithoutSpace} символов без пробелов в строке");

// Количество букв во введенной пользователем строке.
string string3 = Console.ReadLine();
int letterCount = 0;

foreach (char count in string3)
{
    if (Char.IsLetter(count))
    {
        letterCount++;
    }
}
Console.WriteLine($"{letterCount} букв(ы) в строке");

// Все позиции, на которых во введенной пользователем строке находится указанный пользователем символ.
Console.WriteLine("Введите строку: ");
string string4 = Console.ReadLine();

Console.WriteLine("Введите символ: ");
char symbol = Console.ReadKey().KeyChar;
Console.WriteLine();

List<int> positions = new List<int>();
for (int i = 0; i < string4.Length; i++)
{
    if (string4[i] == symbol)
    {
        positions.Add(i);
    }
}
if (positions.Count > 0)
{
    Console.WriteLine($"Символ \"{symbol}\" найден на позиции(-ях): ");
    foreach (int position in positions)
    {
        Console.WriteLine(position + 1);
    }
}
else
{
    Console.WriteLine("Символ не был найден");
}


