﻿//Количество символов
Console.WriteLine("Введите строку: ");
String s1 = Console.ReadLine();
Console.WriteLine($"Количество символов в строке: {s1.Length}");

//Количество символов без пробелов
Console.WriteLine("Введите строку с пробелами: ");
String s2 = Console.ReadLine();
Console.WriteLine($"Количество символов в строке без учета пробелов: {s2.Replace(" ", "").Length}");

//Количество букв
Console.WriteLine("Введите строку: ");
String s3 = Console.ReadLine();
int letterCount = 0;
foreach (char c in s3)
{
    if (Char.IsLetter(c)) letterCount++;
}
Console.WriteLine($"Количество букв в строке: {letterCount}");

//Все позиции указанного пользователем символа
Console.WriteLine("Введите строку: ");
String s4 = Console.ReadLine();
Console.WriteLine("Введите символ из строки: ");
String symbol = Console.ReadLine();

List<int> positons = new List<int>();

for (int i = 0; i < s4.Length; i++)
{
    if (s4[i].ToString() == symbol)
    {
        positons.Add(i);
    }
}

if (positons.Count > 0)
{
    foreach (int positon in positons)
    {
        Console.WriteLine("Позиция: " + (positon + 1));
    }
}
else
{
    Console.WriteLine("Символа нет");
    return;
}

