﻿using System.Text;
class Program
{
    static void Main()
    {
        // Замена 2 более пробелов на один 
        static string trimAndReduceSpaces(string string5)
        {
            return string.Join(" ", string5.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
        }
        Console.WriteLine("Введите строку: ");
        string string5 = Console.ReadLine();

        string trimmedString = trimAndReduceSpaces(string5);
        Console.WriteLine($"строка после обрезки и уменьшения пробелов: {trimmedString}");
        
        static string changeCase(string string6, string caseType)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in string6)
            {
                switch (caseType)
                {
                    case "upper":
                        result.Append(char.ToUpper(c));
                        break;
                    case "lower":
                        result.Append(char.ToLower(c));
                        break;
                    case "invert":
                        if (char.IsUpper(c))
                            result.Append(char.ToLower(c));
                        else if (char.IsLower(c))
                            result.Append(char.ToUpper(c));
                        else
                            result.Append(c);
                        break;
                }
            }
            return result.ToString();
        }
        Console.WriteLine("Введите строку: ");
        string string6 = Console.ReadLine();

        Console.WriteLine("Выберите тип регистра: upper (ВЕРХНИЙ), lower (нижний), invert (инвертиРОВАННЫЙ)");
        string caseType = Console.ReadLine();
        string changeCaseString = changeCase(string6, caseType);

        Console.WriteLine($"Строка после изменения регистра: {changeCaseString}");
    }
}
