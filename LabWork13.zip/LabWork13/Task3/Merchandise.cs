﻿public class Merchandise
{
    public string Name { get; set; }
    public double Price { get; set; }
    public DateTime ExpirationDate { get; set; }

    public override string ToString()
    {
        string formattedName = char.ToUpper(Name[0]) + Name.Substring(1).ToLower();

        string formattedPrice = Price.ToString("0.00");

        string formattedExpirationDate = ExpirationDate.ToString("yyyy-MM-dd");

        return $"{formattedName}, {formattedPrice}, {formattedExpirationDate}";
    }
}
