﻿class Program
{
    static void Main()
    {
        Merchandise merchandise = new Merchandise
        {
            Name = "молоко", 
            Price = 49.99,
            ExpirationDate = new DateTime(2024, 10, 12)
        };
        Console.WriteLine(merchandise.ToString());
    }
}
