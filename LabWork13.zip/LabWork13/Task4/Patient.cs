﻿public class Patient
{
    public string Fullname { get; set; }
    public int Policy { get; set; }
    public DateTime BirthDay { get; set; }

    public override string ToString()
    {
        string formattedFullname = Fullname.ToUpper();

        string formattedPolicy = Policy.ToString("D9");

        string formattedBirthDay = BirthDay.ToString("yyyy/MM/dd");

        return $"{formattedFullname}; {formattedPolicy}; {formattedBirthDay}";
    }
}
