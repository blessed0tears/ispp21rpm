﻿class Program
{
    static void Main()
    {
        Patient patient = new Patient
        {
            Fullname = "Шубина Мария Данииловна",
            Policy = 534252,
            BirthDay = new DateTime(1970, 4, 11)
        };
        Console.WriteLine(patient.ToString());
    }
}
