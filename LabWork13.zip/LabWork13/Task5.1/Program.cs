﻿class Program
{
    static void Main()
    {
        string[] array = { "Апельсин", "Ананас", "Арбуз", "Банан", "Груша", "Яблоко" };
        Console.WriteLine("Введите текст для поиска строк: ");
        string userInput = Console.ReadLine();

        var results = array.Where(s => s.Contains(userInput, StringComparison.OrdinalIgnoreCase)).ToList();

        if (results.Count > 0)
        {
            Console.WriteLine("Строки, содержащие указанный текст:");
            foreach (var item in results)
            {
                Console.WriteLine(item);
            }
        }
        else
        {
            Console.WriteLine("Совпадений не найдено.");
        }
    }
}
