﻿using System.Text.RegularExpressions;

string input = "8(950)456-98-25";
string pattern = @"^(\+7|8)\(9\d{2}\)\d{3}(-\d{2}){2}$";

Regex regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);

Console.WriteLine(regex.Match(input));
if (regex.Match(input).Success)
{
    Console.WriteLine("Правильный номер телефона");
}
else
{
    Console.WriteLine("Неправильный номер телефона");
}
