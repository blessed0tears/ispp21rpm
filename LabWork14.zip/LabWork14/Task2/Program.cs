﻿using System;
using System.Text.RegularExpressions;
string input = "Let's  go  dadada   aga ygy";
string pattern = @"\s+";
Regex regex = new Regex(pattern,RegexOptions.IgnoreCase | RegexOptions.Multiline);

string result = new Regex(@"\s+").Replace(input, " ");

Console.WriteLine(result);
