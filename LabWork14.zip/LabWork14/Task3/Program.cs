﻿using System;
using System.Text.RegularExpressions;

string email = "dwaw1-d@wbib1a.cmmfff.gDas";
string Pattern = @"@\w+\.\w{2,}.\w[a-zA-Z]+$";
Regex regex = new(Pattern);

bool isMatch = Regex.IsMatch(email, Pattern);
Console.WriteLine(isMatch ? "Номер правильный" : "Номер не правильный");


