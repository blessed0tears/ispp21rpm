﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace _2
{
    internal class Program
    {
        static void Sum(int a, int b)
        {
            Console.WriteLine($"Sum: {a + b}");
        }

        static void Difference(int a, int b)
        {
            Console.WriteLine($"Difference: {a - b}");
        }

        static void Product(int a, int b)
        {
            Console.WriteLine($"Product: {a * b}");
        }

        static void Quotient(int a, int b)
        {
            Console.WriteLine($"Quotient: {a / b}");
        }

        public delegate int Function1(int a, int b);

        static void Main(string[] args)
        {
            Function function1 = null;
            function1 += Sum;
            function1 += Difference;
            function1 += Product;
            function1 += Quotient;

            int x = 10;
            int y = 5;

            Console.WriteLine($"x = {x}, y ={y}");
            function1(x, y);
        }
    }
}
