﻿namespace LabWork15
{
    internal class Program
    {
        static int Factorial(int x)
        {
            if (x < 0)
                return -1;

            if (x == 0)
                return 1;
            return x * Factorial(x - 1);
        }

        public delegate int Function(int x);
        static void Main(string[] args)
        {
            Function function1 = x => x * x;
            Function function2 = Factorial;
            Function function3 = x => Math.Abs(x);
            Console.WriteLine(function1(4));
            Console.WriteLine(function2(-3));
            Console.WriteLine(function3(-5));

        }
    }
}