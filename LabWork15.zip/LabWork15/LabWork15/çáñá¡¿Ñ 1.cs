﻿namespace LabWork15
{
    internal class Program
    {
        delegate int Function(int x);

        static void Main(string[] args)
        {
            int x = 5;
            Console.WriteLine($"Исходное число = {x}");
            Function function = x => x * x;
            Console.WriteLine($"x в квадрате = {function(x)}");
            function = Factorial;
            Console.WriteLine($"Факториал от x = {function(x)}");
            function = Math.Abs;
            Console.WriteLine($"Модуль x = {function(x)}");
        }

        static int Factorial(int x)
        {
            if ( x < 0 ) 
            {
                return 0;
            }
            int result = 1;
            if (x == 0)
            {
                return 1;
            }
            for (int i = 1; i <= x; i++)
            {
                result *= i;
            }
            return result;
        }
    }
}
