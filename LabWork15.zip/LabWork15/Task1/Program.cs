﻿public class Program
{
    delegate int IntOperation(int x);
    static void Main()
    {
        int NumberDegree(int x)
        {
            return x * x;
        }

        int Factorial(int x)
        {
            if (x < 0) return -1;
            int result = 1;
            for (int i = 1; i <= x; i++)
                result *= i;
            return result;
        }

        int AbsoluteValue(int x)
        {
            return Math.Abs(x);
        }

        IntOperation operation;
        operation = NumberDegree;
        Console.WriteLine($"Степень числа 4: {operation(4)}");

        operation = Factorial;
        Console.WriteLine($"Факториал 4: {operation(4)}");

        operation = AbsoluteValue;
        Console.WriteLine($"Модуль -4: {operation(-4)}");
    }
}
