﻿class Program
{
    delegate void MathOperation(int x, int y);
    static void Main(string[] args)
    {
        MathOperation operation = Sum;         
        operation += Dif;
        operation += Mult;
        operation += Div;

        int x = 10;
        int y = 20;

        operation(x, y);
    }

    static void Sum(int x, int y)
    {
        Console.WriteLine($"{x} + {y} = {x + y}");
    }

    static void Dif(int x, int y)
    {
        Console.WriteLine($"{x} - {y} = {x + y}");
    }

    static void Mult(int x, int y)
    {
        Console.WriteLine($"{x} * {y} = {x * y}");
    }

    static void Div(int x, int y)
    {
        if (y != 0)
            Console.WriteLine($"{x} / {y} = {x / y}");
        else
            Console.WriteLine("Деление на ноль");
    }
}