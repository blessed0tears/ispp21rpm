namespace Task3
{
    public partial class Form1 : Form
    {
        public TextBox multilineTextBox;
        public Form1()
        {
            InitializeComponent();

            multilineTextBox = new TextBox
            {
                Multiline = true,
                Width = 400,
                Height = 300
            };

            Button replaceButton = new Button
            {
                Text = "������",
                Width = 100
            };
            replaceButton.Click += replaceButton_Click_1;

            Controls.Add(multilineTextBox);
            Controls.Add(replaceButton);
        }        

        private void PerformReplacement(string searchText, string replaceText)
        {
            multilineTextBox.Text = multilineTextBox.Text.Replace(searchText, replaceText);
        }

        private void replaceButton_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(PerformReplacement);
            form2.Show();
        }
    }
}
