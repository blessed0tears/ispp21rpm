﻿namespace Task3
{
    public partial class Form2 : Form
    {

        private Action<string, string> _replaceAction;

        public Form2(Action<string, string> replaceAction)
        {
            InitializeComponent();
            _replaceAction = replaceAction;

            TextBox searchTextBox = new TextBox { Width = 200 };
            TextBox replaceTextBox = new TextBox { Width = 200 };
            Button applyReplaceButton = new Button { Text = "Заменить", Width = 100 };
            applyReplaceButton.Click += (sender, e) => _replaceAction(searchTextBox.Text, replaceTextBox.Text);

            Controls.Add(searchTextBox);
            Controls.Add(replaceTextBox);
            Controls.Add(applyReplaceButton);
        }
    }
}
