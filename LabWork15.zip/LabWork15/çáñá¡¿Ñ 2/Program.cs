﻿namespace Задание_2
{
    internal class Program
    {
        delegate void MathOperation(int a, int b);
        static void Main()
        {
            MathOperation mathDelegate = new MathOperation(PerformOperations);
            mathDelegate.Invoke(9, 3);
        }

        static void PerformOperations(int a, int b)
        {
            Console.WriteLine($"Сумма: {a + b}");
            Console.WriteLine($"Разность: {a - b}");
            Console.WriteLine($"Произведение: {a * b}");
            if (b != 0)
            {
                Console.WriteLine($"Частное: {a / (double)b}");
            }
        }
    }
}
