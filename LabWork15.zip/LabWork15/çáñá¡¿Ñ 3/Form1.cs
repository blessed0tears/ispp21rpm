namespace Задание_3
{
    public Action<string> action;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Search s = new Search();
            s.Show();
        }
    }
}
