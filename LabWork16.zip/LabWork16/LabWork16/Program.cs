﻿using System.ComponentModel;

namespace LabWork16
{
    public class InfoEventArgs : EventArgs
    {
        public string PropertyName { get; set; }
        public string ErrorMassage { get; set; }
        public DateTime ChangeDate { get; set; }
    }
    public class User : INotifyPropertyChanged
    {
        private string _login;
        private string _password;

        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler<InfoEventArgs> InfoEvent;

        public string Login
        {
            get { return _login; }
            set
            {
                if (_login != value)
                {
                    _login = value;
                    RaisePropertyChanged("login");
                }
            }
        }
        public string Password
        {
            get { return _password; }
            set
            {
                if (_password != value)
                {
                    _password = value;
                    RaisePropertyChanged("password");
                }
            }
        }
        private void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            InfoEventArgs eventArgs = new InfoEventArgs
            {
                PropertyName = propertyName,
                ChangeDate = DateTime.Now,
            };
            if (propertyName == "login")
            {
                if (string.IsNullOrEmpty(Login))
                    eventArgs.ErrorMassage = "Ошибочка логин пустой";
                else
                    eventArgs.ErrorMassage = "";
            }
            else if (propertyName == "password")
            {
                if (Password.Length <= 6 || Password.Length >= 20)
                    eventArgs.ErrorMassage = "Ошибка, пароль должен содержать от 6 до 20 символов!";
                else
                    eventArgs.ErrorMassage = "";
            }
            InfoEvent?.Invoke(this, eventArgs);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();
            user.PropertyChanged += User_PropertyChanged;
            user.InfoEvent += User_InfoEvent;
            

            user.Login = "Vlad";
            user.Password = "Abobas";
        }
        private static void User_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            Console.WriteLine($"Изменено свойство: {e.PropertyName}");
        }
        private static void User_InfoEvent(object sender, InfoEventArgs e)
        {
            Console.WriteLine($"Изменены данные пользователя со следующим {e.PropertyName}: {((User)sender).Login}. Дата изменения: {e.ChangeDate}");
        }
       
    }
}

