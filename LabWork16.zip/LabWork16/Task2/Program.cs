﻿using System;

namespace LabWork16
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();
            user.LoginOrPasswordChanged += User_LoginOrPasswordChanged;

            // Изменение свойств для тестирования
            user.Login = "newLogin";
            user.Password = "newPassword";
        }

        private static void User_LoginOrPasswordChanged(object sender, EventArgs e)
        {
            User user = sender as User;
            if (user != null)
            {
                Console.WriteLine($"Изменены данные пользователя со следующим логином: {user.Login}");
            }
        }
    }
}
