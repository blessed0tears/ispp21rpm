﻿using System;

namespace LabWork16
{
    public class User
    {
        private string _login;
        private string _password;

        public string Login
        {
            get { return _login; }
            set
            {
                if (_login != value)
                {
                    _login = value;
                    OnLoginOrPasswordChanged();
                }
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnLoginOrPasswordChanged();
                }
            }
        }

        public event EventHandler LoginOrPasswordChanged;

        protected virtual void OnLoginOrPasswordChanged()
        {
            LoginOrPasswordChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
