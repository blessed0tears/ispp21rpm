﻿namespace Labwork16
{
    using System;
    using static Labwork16.User;

    namespace UserApp
    {
        class Program
        {
            static void Main(string[] args)
            {
                User user = new User();
                user.LoginOrPasswordChanged += User_LoginOrPasswordChanged;
                
                user.Login = "";  // Некорректный логин                
                user.Password = "123";  // Некорректный пароль
                user.Login = "ASBHASF";  // Корректный логин
                user.Password = "validPassword";  // Корректный пароль
            }

            private static void User_LoginOrPasswordChanged(object sender, InfoEventArgs e)
            {
                User user = sender as User;
                if (user != null)
                {
                    Console.WriteLine($"Дата: {e.ChangeDate}, у пользователя логин: {user.Login}, изменено свойство: {e.PropertyName}.");
                    if (!string.IsNullOrEmpty(e.TextError))
                    {
                        Console.WriteLine($"Ошибка: {e.TextError}");
                    }
                }
            }
        }
    }

}
