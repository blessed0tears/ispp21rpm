﻿namespace Labwork16
{
    public class User
    {
        private string _login;
        private string _password;

        public class InfoEventArgs : EventArgs
        {
            public string PropertyName { get; set; }
            public string TextError { get; set; }
            public DateTime ChangeDate { get; set; }
        }

        public string Login
        {
            get { return _login; }
            set
            {
                if (_login != value)
                {
                    _login = value;
                    OnLoginOrPasswordChanged("логин");
                }
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnLoginOrPasswordChanged("пароль");
                }
            }
        }

        public event EventHandler<InfoEventArgs> LoginOrPasswordChanged;

        protected virtual void OnLoginOrPasswordChanged(string propertyName)
        {
            var errorText = "";
            if (propertyName == "логин" && string.IsNullOrWhiteSpace(_login))
            {
                errorText = "Логин не может быть пустым.";
            }
            else if (propertyName == "пароль" && (_password.Length < 6 || _password.Length > 20))
            {
                errorText = "Пароль должен быть от 6 до 20 символов.";
            }

            var args = new InfoEventArgs
            {
                PropertyName = propertyName,
                TextError = errorText,
                ChangeDate = DateTime.Now
            };

            LoginOrPasswordChanged?.Invoke(this, args);
        }
    }
}
