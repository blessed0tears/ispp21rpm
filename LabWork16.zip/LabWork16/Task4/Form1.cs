using System;
using System.Windows.Forms;

namespace Task4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SubscribeDigitButtons();
        }

        private void SubscribeDigitButtons()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button && control.Text != "��������")
                {
                    control.Click += DigitButton_Click;
                }
            }

            clearButton.Click += ClearButton_Click;
        }

        private void DigitButton_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                inputTextBox.Text += button.Text;
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            inputTextBox.Text = string.Empty;
        }
    }
}
