namespace Task5
{

    public delegate void TextReplacementHandler(string oldText, string newText);

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            replaceButton.Click += ReplaceButton_Click;
        }

        private void ReplaceButton_Click(object sender, EventArgs e)
        {
            Form2 replacementForm = new Form2();
            replacementForm.TextReplaced += ReplacementForm_TextReplaced;
            replacementForm.ShowDialog();
        }

        private void ReplacementForm_TextReplaced(string oldText, string newText)
        {
            textBox.Text = textBox.Text.Replace(oldText, newText);
        }
    }    
}
