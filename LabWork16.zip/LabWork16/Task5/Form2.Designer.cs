﻿namespace Task5
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            replaceButton = new Button();
            oldTextBox = new TextBox();
            newTextBox = new TextBox();
            SuspendLayout();
            // 
            // replaceButton
            // 
            replaceButton.Location = new Point(361, 409);
            replaceButton.Name = "replaceButton";
            replaceButton.Size = new Size(75, 23);
            replaceButton.TabIndex = 0;
            replaceButton.Text = "Заменить";
            replaceButton.UseVisualStyleBackColor = true;
            // 
            // oldTextBox
            // 
            oldTextBox.Location = new Point(12, 12);
            oldTextBox.Multiline = true;
            oldTextBox.Name = "oldTextBox";
            oldTextBox.Size = new Size(776, 173);
            oldTextBox.TabIndex = 1;
            // 
            // newTextBox
            // 
            newTextBox.Location = new Point(12, 191);
            newTextBox.Multiline = true;
            newTextBox.Name = "newTextBox";
            newTextBox.Size = new Size(776, 198);
            newTextBox.TabIndex = 1;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(newTextBox);
            Controls.Add(oldTextBox);
            Controls.Add(replaceButton);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button replaceButton;
        private TextBox oldTextBox;
        private TextBox newTextBox;
    }
}