﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task5
{
    public partial class Form2 : Form
    {
        public event TextReplacementHandler TextReplaced;

        public Form2()
        {
            InitializeComponent();
            replaceButton.Click += ReplaceButton_Click;
        }

        private void ReplaceButton_Click(object sender, EventArgs e)
        {
            string oldText = oldTextBox.Text;
            string newText = newTextBox.Text;
            TextReplaced?.Invoke(oldText, newText);
            this.Close();
        }
    }
}
