namespace LabWork17
{
    public partial class Task1 : Form
    {
        FileInfo[] GetFiles(string directoryName)
        {
            DirectoryInfo directory = new DirectoryInfo(directoryName);
            return directory.GetFiles("*", SearchOption.AllDirectories);
        }

        public Task1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            var files = GetFiles(path)
                .Select(file => new { file.Name, file.DirectoryName, file.Length, file.CreationTime })
                .OrderBy(file => file.Name)
                .ThenByDescending(file => file.CreationTime);
            dgv.DataSource = files.ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            var files = GetFiles(path)
                .Select(file => new { file.Extension })
                .Distinct();
            dgv.DataSource = files.ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            var files = GetFiles(path)
                .GroupBy(file => file.Extension)
                .Select(gr => new { Extension = gr.Key, Count = gr.Key.Count() });
            dgv.DataSource = files.ToList();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            var files = GetFiles(path)
                .Where(f => f.Name.Contains(searchTextBox.Text))
                .Select(f => new { f.Name, f.FullName });

            dgv.DataSource = files.ToList();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            DirectoryInfo directory = new DirectoryInfo(path);
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var query = files
                .Where(f => f.CreationTime.Date == DateTime.Today)
                .OrderByDescending(f => f.CreationTime)
                .Take(5);

            dgv.DataSource = query.Select(f => new { f.Name, f.CreationTime }).ToList();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            DirectoryInfo directory = new DirectoryInfo(path);
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var query = new
            {
                FileCount = files.Length,
                TotalSizeMB = files.Sum(f => f.Length) / (1024 * 1024)
            };

            dgv.DataSource = new[] { query }.ToList();
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            DirectoryInfo directory = new DirectoryInfo(path);
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var query = files.Select(f => new
            {
                f.Name,
                f.Extension,
                f.FullName,
                SizeWithUnit = GetSizeWithUnit(f.Length)
            });

            dgv.DataSource = query.ToList();
        }
        private string GetSizeWithUnit(long size)
        {
            if (size < 1024)
                return $"{size} �";
            if (size < 1024 * 1024)
                return $"{size / 1024.0:F2} ��";
            return $"{size / (1024.0 * 1024.0):F2} ��";
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            string path = pathTextBox.Text;
            DirectoryInfo directory = new DirectoryInfo(path);
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);            
            var query = files.Count(f => f.Name == searchTextBox.Text);

            dgv.DataSource = new[] { new { FileName = searchTextBox.Text, Count = query } }.ToList();
        }
    }
}

