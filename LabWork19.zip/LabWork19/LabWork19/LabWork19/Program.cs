﻿namespace LabWork19
{
    internal class Program
    {
        static void StrategyPatternDemo(string[] args)
        {
            Context context = new Context(new OperationAdd());
            Console.WriteLine("10 + 5 = " + context.ExecuteStrategy(10, 5));
            context = new Context(new OperationSubstract());
            Console.WriteLine("10 - 5 = " + context.ExecuteStrategy(10, 5));
            context = new Context(new OperationMultiply());
            Console.WriteLine("10 * 5 = " + context.ExecuteStrategy(10, 5));
        }

    }

}
public interface IStrategy
{
    int Execute(int number1, int number2);
}

public class OperationAdd : IStrategy
{
    public int Execute(int number1, int number2)
    {
        return number1 + number2;
    }
}

public class OperationSubstract : IStrategy
{
    public int Execute(int number1, int number2)
    {
        return number1 - number2;
    }
}

public class OperationMultiply : IStrategy
{
    public int Execute(int number1, int number2)
    {
        return number1 * number2;
    }
}

public class Context
{
    private IStrategy strategy;

    public Context(IStrategy strategy)
    {
        this.strategy = strategy;
    }

    public int ExecuteStrategy(int number1, int number2)
    {
        return strategy.Execute(number1, number2);
    }
}