﻿int[] numbers = { 1, 3, 2, 9, 8, 7, 6 };
for (int i = 0; i < numbers.Length; i++)
{
    Console.Write($"{numbers[i]} ");
}
Console.WriteLine();
int number = 2;
int position = -1;
for (int i = 1; i < numbers.Length; i++)
{
    if (numbers[i] == number)
    {
        position = i;
        break;
    }
}
Console.WriteLine($"Индекс элемента = {position}");