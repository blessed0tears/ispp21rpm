﻿using LabWork20.Models2;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class GamesController : ControllerBase
{

    [HttpGet]
    public ActionResult<IEnumerable<Game>> GetAllGames()
    {
        return Ok(GameRepository.Games);
    }

    [HttpGet("{id}")]
    public ActionResult<Game> GetGameById(int id)
    {
        var game = GameRepository.Games.FirstOrDefault(g => g.IdGame == id);
        if (game == null)
        {
            return NotFound();
        }
        return Ok(game);
    }

    [HttpGet("category/{category}")]
    public ActionResult<IEnumerable<Game>> GetGamesByCategory(string category)
    {
        var games = GameRepository.Games.Where(g => g.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
        if (games == null || !games.Any())
        {
            return NotFound();
        }
        return Ok(games);
    }

    [HttpGet("paged")]
    public ActionResult<IEnumerable<Game>> GetPagedGames([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
    {
        var pagedGames = GameRepository.Games
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        return Ok(pagedGames);
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteGame(int id)
    {
        var game = GameRepository.Games.FirstOrDefault(g => g.IdGame == id);
        if (game == null)
        {
            return NotFound();
        }

        GameRepository.Games.Remove(game);
        return NoContent();
    }
}
