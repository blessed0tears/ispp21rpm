﻿// вычисление площади кольца
int r1 = 5;
int r2 = 6;double area = Math.Abs(Math.PI * (r1 * r1 - r2 * r2));Console.WriteLine("result = " + area);// сумма чисел от 1 до n (заменить на сумму ряда натуральных чисел)
int n = 10;
int sum = n * (n + 1) / 2;
Console.WriteLine("result = " + sum);