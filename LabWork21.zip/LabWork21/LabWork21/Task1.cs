﻿int Sum(int number1, int number2)
    => number1 + number2;
Console.WriteLine(Sum(1, 4));
