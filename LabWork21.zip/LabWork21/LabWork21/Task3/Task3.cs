﻿string GetSize(int bytes)
{
    if (bytes < 1024)
        return $"{bytes} Байты";
    double kb = bytes / 1024;
    if (kb < 1024)
        return $"{kb}КилоБайты";
    double mb = kb / 1024;
    if (mb < 1024)
        return $"{mb}МегайБайты";
    double gb = mb / 1024;
        return $"{gb}ГигаБайты";
}