﻿int GetDaysCount(int month, int year)
{
    if (month < 1 || month > 12)
        return -1;
    if (month == 2)
        return (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) ? 29 : 28;

    return (month == 4 || month == 6 || month == 9 || month == 11) ? 30 : 31;
}
Console.WriteLine(GetDaysCount(4, 2024));