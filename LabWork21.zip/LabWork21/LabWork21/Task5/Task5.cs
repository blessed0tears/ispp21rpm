﻿static long FastDegree(int Number, int Degree)
{
    if (Degree < 0)
    {
        return -1;
    }
    if (Degree == 0)
    {
        return 1;
    }
    if (Degree % 2 == 0)
    {
        long temp = FastDegree(Number, Degree / 2);
        return temp * temp;
    }
    else
    {
        long temp = FastDegree(Number, (Degree - 1) / 2);
        return Number * temp * temp;
    }
}
Console.WriteLine($"result = {FastDegree(0,-1)}");