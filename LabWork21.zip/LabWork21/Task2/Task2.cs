﻿// вычисление площади кольца
double R = 12.3;
double r = 2.2;
double s = Math.Abs(Math.PI * Math.Pow(R - r, 2));
Console.WriteLine(s);

// сумма чисел от 1 до n
int n = 10;
Console.WriteLine(n * (n + 1) / 2);
