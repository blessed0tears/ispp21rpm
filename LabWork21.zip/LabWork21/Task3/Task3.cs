﻿string GetSize(long bytes)
{
    if (bytes < 1024)
    {
        return $"{bytes} Б";
    }
    double kb = bytes / 1024;

    if (kb < 1024)
    {
        return $"{kb} КБ";
    }
    double mb = kb / 1024;

    if (mb < 1024)
    {
        return $"{mb} МБ";
    }
    double gb = mb / 1024;
    return $"{gb} ГБ";
}

Console.WriteLine(GetSize(6324876));