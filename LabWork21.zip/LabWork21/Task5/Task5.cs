﻿static double FastPower(double baseNum, int expanent)
{
    if (expanent < 0)
    {
        return -1;
    }
    else if (expanent == 0)
    {
        return 1;
    }
    else if (expanent % 2 == 0)
    {
        double temp = FastPower(baseNum, expanent / 2);
        return temp * temp;
    }
    else
    {
        return baseNum * FastPower(baseNum, expanent - 1);
    }
}
Console.WriteLine(FastPower(2, 5));
Console.WriteLine(FastPower(3, 4));
