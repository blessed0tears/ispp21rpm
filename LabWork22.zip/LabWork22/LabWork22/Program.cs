﻿namespace LabWork22
{
    internal class Program
    {
        static async Task Degree(int a, int x)
        {
            int result = Power(a, x);
            Console.WriteLine($"{a}^{x} = {result}");
        }
        static async Task DegreeParallelAsync(int a, int x)
        {
            int result = Power(a, x);
            Console.WriteLine($"{a}^{x} = {result}");
        }
        static int Power(int a, int x)
        {
            if (x < 0)
                return -1;
            if (x == 0)
                return 1;
            if (x == 1)
                return a;

            int result = 1;
            for (int i = 0; i < x; i++)
            {
                result *= a;
            }

            return x > 0 ? result : 1 / result;
        }
        static async Task Main(string[] args)
        {
            await Degree(1, 2);
            await Degree(3, 3);
            await Degree(3, 7);
            Console.WriteLine("параллельный асинхронный вызов: ");
            await Task.WhenAll
                (
                DegreeParallelAsync(2, 5),
                DegreeParallelAsync(2, 4),
                DegreeParallelAsync(2, 3)
                );
        }
    }
}
