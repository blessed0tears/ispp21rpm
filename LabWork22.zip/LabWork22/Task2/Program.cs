﻿using System.Threading.Tasks;

namespace LabWork22
{
    internal class Program
    {
        static async Task expression(int a1, int a2, int a3, int a4, int x1, int x2, int x3, int x4)
        {
            int result1 = 1;
            for (int i = 1; i < x1;i++)
            {
                result1 *= a1;
            }
            int result2 = 1;
            for (int i = 1; i < x2; i++)
            {
                result1 *= a2;
            }
            int result3 = 1;
            for (int i = 1; i < x3; i++)
            {
                result1 *= a3;
            }
            int result4 = 1;
            for (int i = 1; i < x4; i++)
            {
                result1 *= a4;
            }
            int  ji = (result1 + result2) / (result3 - result4);
           
        }
        static async Task Degree(int a, int x)
        {
            int result = Power(a, x);
            Console.WriteLine($"{a}^{x} = {result}");
        }
        static async Task DegreeParallelAsync(int a, int x)
        {
            int result = Power(a, x);
            Console.WriteLine($"{a}^{x} = {result}");
        }
        static int Power(int a, int x)
        {
            if (x < 0)
                return -1;
            if (x == 0)
                return 1;
            if (x == 1)
                return a;

            int result = 1;
            for (int i = 0; i < x; i++)
            {
                result *= a;
            }

            return x > 0 ? result : 1 / result;
        }
        static async Task Main(string[] args)
        {
            await Degree(1, 2);
            await Degree(3, 3);
            await Degree(3, 7);
            Console.WriteLine("параллельный асинхронный вызов: ");
            await Task.WhenAll
                (
                DegreeParallelAsync(2, 5),
                DegreeParallelAsync(2, 4),
                DegreeParallelAsync(2, 3)
                );
    
            await expression(2, 3, 4, 5, 6, 7, 8, 9);
        }
    }
}
