﻿namespace LabWork22
{
    class Program
    {
        static async Task Main()
        {
            await WriteRandomNumbersToFile("random_numbers.txt", 100000);
            Console.WriteLine("Конец программы");
        }

        static async Task WriteRandomNumbersToFile(string filename, int numberOfLines)
        {
            Console.WriteLine($"Запись в файл {filename} начата.");
            Random random = new();
            using (StreamWriter writer = new(filename, false))
            {
                for (int i = 1; i <= numberOfLines; i++)
                {
                    await writer.WriteLineAsync($"Число №{i}: {random.Next()}");
                }
            }
            Console.WriteLine($"Запись в файл {filename} закончена.");
        }
    }
}