﻿class Program
{
    static async Task Main(string[] args)
    {

        await WriteRandomNumbersToFile("random_numbers1.txt", 100000);
        await WriteRandomNumbersToFile("random_numbers2.txt", 100000);
        await WriteRandomNumbersToFile("random_numbers3.txt", 100000);

        await Task.WhenAll(
            ReadLinesFromFile("random_numbers1.txt"),
            ReadLinesFromFile("random_numbers2.txt"),
            ReadLinesFromFile("random_numbers3.txt")
        );
    }  

    static async Task WriteRandomNumbersToFile(string filename, int numberOfLines)
    {
        Console.WriteLine($"Запись в файл {filename} начата.");
        Random random = new();
        using (StreamWriter writer = new(filename, false))
        {
            for (int i = 1; i <= numberOfLines; i++)
            {
                await writer.WriteLineAsync($"Число №{i}: {random.Next()}");
            }
        }
        Console.WriteLine($"Запись в файл {filename} закончена.");
    }

    static async Task ReadLinesFromFile(string filename)
    {
        Console.WriteLine($"Чтение из файла {filename} начато.");
        using (StreamReader reader = new StreamReader(filename))
        {
            string line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                Console.WriteLine($"{filename}: {line}");
            }
        }
        Console.WriteLine($"Чтение из файла {filename} закончено.");
    }
}
