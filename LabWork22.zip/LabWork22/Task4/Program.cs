﻿using System;
using System.IO;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        await WriteRandomNumbersToFile("random_numbers.txt", 100000);
        await ReadLinesFromFile("random_numbers.txt");
    }

    static async Task WriteRandomNumbersToFile(string filename, int numberOfLines)
    {
        Console.WriteLine($"Запись в файл {filename} начата.");
        Random random = new();
        using (StreamWriter writer = new(filename, false))
        {
            for (int i = 1; i <= numberOfLines; i++)
            {
                await writer.WriteLineAsync($"Число №{i}: {random.Next()}");
            }
        }
        Console.WriteLine($"Запись в файл {filename} закончена.");
    }    

    static async Task ReadLinesFromFile(string filename)
    {
        Console.WriteLine($"Чтение из файла {filename} начато.");
        using (StreamReader reader = new(filename))
        {
            string line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                Console.WriteLine($"{filename}: {line}");
            }
        }
        Console.WriteLine($"Чтение из файла {filename} закончено.");
    }
}
