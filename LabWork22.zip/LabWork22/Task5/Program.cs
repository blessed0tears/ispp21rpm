﻿class Program
{
    static async Task Main(string[] args)
    {
        await WriteRandomNumbersToFile("random_numbers.txt", 100000);
        var cts = new CancellationTokenSource();
        cts.CancelAfter(5000); // Отмена операции через 5 секунд
        try
        {
            await ReadLinesFromFile("random_numbers.txt", cts.Token);
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Операция была отменена.");
        }
    }    

    static async Task WriteRandomNumbersToFile(string filename, int numberOfLines)
    {
        Random random = new();
        using (StreamWriter writer = new(filename, false))
        {
            for (int i = 1; i <= numberOfLines; i++)
            {
                await writer.WriteLineAsync($"Число №{i}: {random.Next()}");
            }
        }        
    }

    static async Task ReadLinesFromFile(string filename, CancellationToken token)
    {
        Console.WriteLine($"Чтение из файла {filename} начато.");
        using (StreamReader reader = new StreamReader(filename))
        {
            string line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                token.ThrowIfCancellationRequested();
                Console.WriteLine($"{filename}: {line}");
            }
        }
        Console.WriteLine($"Чтение из файла {filename} закончено.");
    }
}
