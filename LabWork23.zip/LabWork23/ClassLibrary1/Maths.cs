﻿namespace LabWorkLibrary
{
    public class Maths
    {
        public const int BINARY_FACTOR = 1024;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        static public double Addition(double a, double b)
        {
            return a + b;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        static public double Difference(double a, double b)
        {
            return a - b;
        }

        /// <summary>
        /// Возвращает  чисел 
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        static public double Multiplication(double a, double b)
        {
            return a * b;
        }

        /// <summary>
        /// Возвращает деление чисел 
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        static public double Division(double a, double b)
        {
            return a / b;
        }

        /// <summary>
        /// Вычисляет площадь прямогугольника
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        static public double RectangleArea(double width, double height)
        {
            return width * height;
        }
    }
}