﻿using LabWorkLibrary;
using System;
namespace LabWork23

{
    internal class Program
    {
        static void Main(string[] args)
        {
            double resultAddition = Maths.Addition(5.1, 3);
            Console.WriteLine("5.1 + 3 = " + resultAddition);

            double resultDifference = Maths.Difference(5, 3);
            Console.WriteLine("5 - 3 = " + resultDifference);

            double resultMultiplication = Maths.Multiplication(5, 3);
            Console.WriteLine("5 * 3 = " + resultMultiplication);

            double resultDivision = Maths.Division(6, 3);
            Console.WriteLine("6 / 3 = " + resultDivision);

            double resultArea = Maths.RectangleArea(5, 3);
            Console.WriteLine("S: 5 * 3 = " + resultArea);

            Console.WriteLine("Const = " + Maths.BINARY_FACTOR);
        }
    }
}