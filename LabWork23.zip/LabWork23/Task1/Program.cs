﻿using LabWorkLibrary;

namespace LabWork23
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 5;
            double b = 3;
            double width = 10;
            double height = 20;

            Console.WriteLine($"Сумма {a} и {b} равна {Maths.Add(a, b)}");
            Console.WriteLine($"Разность {a} и {b} равна {Maths.Subtract(a, b)}");
            Console.WriteLine($"Произведение {a} и {b} равно {Maths.Multiply(a, b)}");
            Console.WriteLine($"Частное {a} и {b} равно {Maths.Divide(a, b)}");
            Console.WriteLine($"Площадь прямоугольника с шириной {width} и высотой {height} равна {Maths.RectangleArea(width, height)}");
            Console.WriteLine($"Константа BINARY_FACTOR равна {Maths.BINARY_FACTOR}");
        }
    }
}
