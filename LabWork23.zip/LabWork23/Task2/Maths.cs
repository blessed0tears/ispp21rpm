﻿/// <summary>
/// Provides mathematical operations.
/// </summary>
public static class Maths
{
    /// <summary>
    /// Коэффициент для двоичных вычислений.
    /// </summary>
    public const int BINARY_FACTOR = 1024;

    /// <summary>
    /// Складывает два числа.
    /// </summary>
    public static double Add(double a, double b)
    {
        return a + b;
    }

    /// <summary>
    /// Вычитает первое число из второго.
    /// </summary>
    public static double Subtract(double a, double b)
    {
        return a - b;
    }

    /// <summary>
    /// Перемножает два числа.
    /// </summary>
    public static double Multiply(double a, double b)
    {
        return a * b;
    }

    /// <summary>
    /// Делит первое число на второе.
    /// </summary>
    /// <exception cref="DivideByZeroException">Делении на ноль.</exception>
    public static double Divide(double a, double b)
    {
        if (b == 0)
        {
            throw new DivideByZeroException("Деление на ноль.");
        }
        return a / b;
    }

    /// <summary>
    /// Вычисляет площадь прямоугольника.
    /// </summary>
    /// <exception cref="ArgumentException">Значение не должно быть меньше или равно нулю.</exception>
    public static double RectangleArea(double width, double height)
    {
        if (width <= 0 || height <= 0)
        {
            throw new ArgumentException("Значение не должно быть меньше или равно нулю.");
        }
        return width * height;
    }
}
