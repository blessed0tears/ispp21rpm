﻿namespace LabWorkLibrary
{
    public static class Maths
    {
        /// <summary>
        /// Adds two integers.
        /// </summary>
        /// <param name="a">Первое целое число.param>
        /// <param name="b">Второе целое число.</param>
        /// <returns>Сумма двух целых чисел.</returns>
        public static double Add(double a, double b)
        {
            return a + b;
        }

        /// <summary>
        /// Вычитает первое целое из второго.
        /// </summary>
        /// <param name="a">Первое число.param>
        /// <param name="b">Второе число.</param>
        /// <returns>Разница между первым и вторым числами.</returns>
        public static double Subtract(double a, double b)
        {
            return a - b;
        }

        /// <summary>
        /// Перемножает два числа.
        /// </summary>
        /// <param name="a">Первое число.param>
        /// <param name="b">Второе число.</param>
        /// <returns>Произведение двух целых чисел.</returns>
        public static double Multiply(double a, double b)
        {
            return a * b;
        }

        /// <summary>
        /// Делит первое число на второе.
        /// </summary>
        /// <param name="a">Первое число.param>
        /// <param name="b">Второе число.</param>
        /// <returns>Деление двух чисел.</returns>
        /// <exception cref="DivideByZeroException">Исключение: деление на ноль</exception>
        public static double Divide(double a, double b)
        {
            if (b == 0)
            {
                throw new DivideByZeroException("Деление на ноль");
            }
            return a / b;
        }

        /// <summary>
        /// Вычисляет площадь прямоугольника.
        /// </summary>
        /// <param name="width">Ширина прямоугольника.</param>
        /// <param name="height">Высота прямоугольника.</param>
        /// <returns>Площадь прямоугольника.</returns>
        /// <exception cref="ArgumentException">Исключение: ширина или высота меньше или равна 0</exception>
        public static double RectangleArea(double width, double height)
        {
            if (width <= 0 || height <= 0)
            {
                throw new ArgumentException("Ширина или высота меньше или равна 0");
            }
            return width * height;
        }
    }
}