﻿namespace LabWork23
{
    class Program
    {
        static void Main(string[] args)
        {
            User user1 = new User { Login = "jsdag", Password = "shdgf", UserRole = Role.Administrator };
            User user2 = new User { Login = "fgdhgfh", Password = "fdsfdf", UserRole = Role.Manager };
        }
    }
}