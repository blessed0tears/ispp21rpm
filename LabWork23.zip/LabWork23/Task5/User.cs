﻿namespace LabWork23
{

    /// <summary>
    /// Определяет роли пользователей.
    /// </summary>
    public enum Role
    {
        /// <summary>
        /// Покупатель.
        /// </summary>
        Customer,

        /// <summary>
        /// Менеджер.
        /// </summary>
        Manager,

        /// <summary>
        /// Администратор.
        /// </summary>
        Administrator
    }

    /// <summary>
    /// Представляет пользователя.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Получает или устанавливает логин.
        /// </summary>
        public string Login { get; set; }

        /// <summary>
        /// Получает или устанавливает пароль.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Получает или устанавливает роль.
        /// </summary>
        public Role UserRole { get; set; }
    }
}