﻿using System.Windows;
using System.Windows.Controls;

namespace LabWork32
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            string checkedItems = "";
            foreach (CheckBox item in ListBox.Items)
            {
                if (item.IsChecked == true)
                {
                    checkedItems += $"{item.Content}\n";
                }
            }
            if (checkedItems != "")
            {
                MessageBox.Show("Элементы : \n" + checkedItems);
            }
            else
            {
                MessageBox.Show("Таких нет");
            }
        }
    }
}

