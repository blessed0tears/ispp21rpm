﻿using System.Windows;
using System.Windows.Controls;

namespace Task2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ComboBox.Items.Add(TextBox.Text);
            ListBox.Items.Add(TextBox.Text);
        }
    }
}
