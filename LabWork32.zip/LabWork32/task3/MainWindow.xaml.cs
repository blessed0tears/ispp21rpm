﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace task3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<User> users = new List<User>();
            users.Add(new User { Id = 1, Login = "Aboba1", Password = "password1" });
            users.Add(new User { Id = 2, Password = "password2", Login = "aboba2" });
            users.Add(new User { Id = 3, Password = "password3", Login = "aboba3 " });
            users.Add(new User { Id = 4, Login = "Aboba4", Password = "password4" });
            users.Add(new User { Id = 5, Password = "password5", Login = "aboba5" });
            ComboBox.ItemsSource = users;
            ListBox.ItemsSource = users;
            ListView.ItemsSource = users;
            ComboBox.DisplayMemberPath = "Login";
            ListBox.DisplayMemberPath = "Login";
            ListView.DisplayMemberPath = "Login";
        }
    }
}
