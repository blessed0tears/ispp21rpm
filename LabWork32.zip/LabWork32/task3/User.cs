﻿namespace task3
{
    public partial class MainWindow
    {
        public class User
        {
            public int Id { get; set; }
            public string Login { get; set; }
            public string Password { get; set; }

            public User()
            {
                Id = 1;
                Login = "Aboba";
                Password = "password";
            }

        }


    }
}
