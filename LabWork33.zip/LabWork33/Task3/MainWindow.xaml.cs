﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<Game> games = new List<Game>();
            games.Add(new Game { IdGame = 1, Name = "CS2", Category = "Shooter", Price = 1100, Site = "Steam" });
            games.Add(new Game { IdGame = 2, Name = "MLBB", Category = "Moba", Price = 0, Site = "Moonton" });
            games.Add(new Game { IdGame = 3, Name = "GTA5", Category = "Action-adventure", Price = 1499, Site = "EpicGames" });
            games.Add(new Game { IdGame = 4, Name = "Rust", Category = "Survival", Price = 725, Site = "Steam" });
            games.Add(new Game { IdGame = 5, Name = "Apex Legends", Category = "Action", Price = 0, Site = "EpicGames" });
            girdik.ItemsSource = games;
            girdik.DisplayMemberPath = "IdGame";
            girdik.DisplayMemberPath = "Name";
            girdik.DisplayMemberPath = "Category";
            girdik.DisplayMemberPath = "Price";
            girdik.DisplayMemberPath = "Site";
        }
        class Game
        {
            public int IdGame { get; set; }
            public string Name { get; set; }
            public string Site { get; set; }
            public string Category { get; set; }
            public double Price { get; set; }
        }
    }
}
