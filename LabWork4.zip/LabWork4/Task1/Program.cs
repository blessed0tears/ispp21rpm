﻿int x = int.Parse(Console.ReadLine());
int y = int.Parse(Console.ReadLine());
int[,] array = new int[x, y];
for (int i = 0; i < x; i++)
{
    for (int j = 0; j < y; j++)
    {
        array[i, j] = -1;
    }
}
Console.WriteLine("Введите координату x начальной ячейки: ");
int startX = int.Parse(Console.ReadLine());
Console.WriteLine("Введите координату y начальной ячейки: ");
int startY = int.Parse(Console.ReadLine());
array[startX - 1, startY - 1] = 0;
Random random = new Random();
int prip = random.Next(1, 10);

for (int k = 0; k < prip; k++)
{
    int pripX = random.Next(0, x);
    int pripY = random.Next(0, y);
    while (array[pripX, pripY] != -1)
    {
        pripX = random.Next(0, x);
        pripY = random.Next(0, y);
    }

    if (k == prip - 1)
    {
        array[pripX, pripY] = 99;
    }
    else
    {
        array[pripX, pripY] = -2;
    }
}

Console.WriteLine("Матрица: ");
for (int i = 0; i < x; i++)
{
    for (int j = 0; j < y; j++)
    {
        Console.Write($"{array[i, j],-4}\t");
    }
    Console.WriteLine("");
}
