﻿public class Program
{
    public static void Main()
    {
        Worker worker1 = new Worker();
        Worker worker2 = new Worker("Иванов Иван Иванович", "Инженер", 50000);

        try
        {
            worker1.FullName = "Петров Петр Петрович";
            worker1.Position = "Менеджер";
            worker1.Salary = 60000;
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message);
        }

        worker1.DisplayInfo();
        worker2.DisplayInfo();
    }
}
