﻿using System;

public class Task3
{
    public static void Main()
    {
        // Создание объектов класса с помощью конструктора по умолчанию и с параметрами
        Worker worker1 = new Worker();
        Worker worker2 = new Worker("Иванов Иван Иванович", "Инженер", 50000);

        // Установка значений через свойства
        try
        {
            worker1.FullName = "Петров Петр Петрович";
            worker1.Position = "Менеджер";
            worker1.Salary = 60000;
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message);
        }

        // Проверка некорректных данных
        try
        {
            worker1.FullName = "";
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message); // Ожидается ошибка
        }

        try
        {
            worker1.Salary = -100;
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message); // Ожидается ошибка
        }

        // Вывод информации о работниках
        worker1.DisplayInfo();
        worker2.DisplayInfo();
    }
}
