﻿using System;

public class Worker
{
    private string fullName;
    private string position;
    private decimal salary;

    // Конструктор по умолчанию
    public Worker()
    {
        fullName = "";
        position = "";
        salary = 0;
    }

    // Конструктор с параметрами
    public Worker(string fullName, string position, decimal salary)
    {
        this.FullName = fullName;
        this.Position = position;
        this.Salary = salary;
    }

    // Свойства с проверкой корректности данных
    public string FullName
    {
        get { return fullName; }
        set
        {
            if (string.IsNullOrEmpty(value) || value.Length < 1)
                throw new ArgumentException("Имя не должно быть пустым или короче 1 символа.");
            fullName = value;
        }
    }

    public string Position
    {
        get { return position; }
        set
        {
            if (string.IsNullOrEmpty(value) || value.Length < 1)
                throw new ArgumentException("Должность не должна быть пустой или короче 1 символа.");
            position = value;
        }
    }

    public decimal Salary
    {
        get { return salary; }
        set
        {
            if (value < 0)
                throw new ArgumentException("Зарплата не должна быть меньше нуля.");
            salary = value;
        }
    }

    // Метод для вывода всей информации об объекте
    public void DisplayInfo()
    {
        Console.WriteLine($"ФИО: {fullName}, Должность: {position}, Зарплата: {salary}");
    }
}