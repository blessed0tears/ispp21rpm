﻿using System;
using System.Linq;

public class Task4
{
    public static void Main()
    {
        Worker[] workers = new Worker[]
        {
            new Worker("Никифорова София Евгеньевна", "Инженер", 50544),
            new Worker("Федоров Михаил Михайлович", "Менеджер", 42545),
            new Worker("Савельев Артём Егорович", "Инженер", 56766),
            new Worker("Полякова Анастасия Никитична", "Директор", 111123),
        };

        // Критерии
        decimal salaryThreshold = 55000;
        string targetPosition = "Инженер";

        // Поиск работников с зарплатой больше заданной
        var highSalaryWorkers = workers.Where(worker => worker.Salary > salaryThreshold);
        Console.WriteLine("Работники с зарплатой больше " + salaryThreshold + ":");
        foreach (var worker in highSalaryWorkers)
        {
            worker.DisplayInfo();
        }

        // Поиск работников, занимающих заданную должность
        var targetPositionWorkers = workers.Where(worker => worker.Position == targetPosition);
        Console.WriteLine("\nРаботники, занимающие должность " + targetPosition + ":");
        foreach (var worker in targetPositionWorkers)
        {
            worker.DisplayInfo();
        }
    }
}
