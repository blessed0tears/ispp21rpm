﻿using System;

public class Worker
{
    private string fullName;
    private string position;
    private decimal salary;

    // Конструктор по умолчанию
    public Worker()
    {
        fullName = "";
        position = "";
        salary = 0;
    }

    // Конструктор с параметрами
    public Worker(string fullName, string position, decimal salary)
    {
        this.FullName = fullName;
        this.Position = position;
        this.Salary = salary;
    }

    
    public string FullName
    {
        get { return fullName; }
        set { fullName = value; }
    }

    public string Position
    {
        get { return position; }
        set { position = value; }
    }

    public decimal Salary
    {
        get { return salary; }
        set { salary = value; }
    }

    // Метод для вывода всей информации об объекте
    public void DisplayInfo()
    {
        Console.WriteLine($"ФИО: {fullName}, Должность: {position}, Зарплата: {salary}");
    }
}