﻿public class Employee
{
    public string fullName;
    public string post;
    public decimal salary;

    public Employee()
    {
        this.fullName = "Unknown";
        this.post = "Employee";
        this.salary = 0;
    }
    // Конструктор с параметрами
    public Employee(string fullname, string post, decimal salary)
    {
        this.fullName = fullname;
        this.post = post;
        this.salary = salary;
    }

   
}