﻿namespace LabWork6
{
    class Program
    {
        static void Main()
        {
            Employee defaultWorker = new Employee();
            Console.WriteLine("По умолчанию:");
            ShowWorkerInfo(defaultWorker);

            Employee withParameter = new Employee("Журавлева Ангелина Данииловна", "Кассир", 10000);
            Console.WriteLine("\nС параметром");
            ShowWorkerInfo(withParameter);
        }
        static void ShowWorkerInfo(Employee workers)
        {
            Console.Write($"ФИО: {workers.fullName}, ");
            Console.Write($"должность: {workers.post}, ");
            Console.Write($"зарплата: {workers.salary}.\n");
        }
    }
}

