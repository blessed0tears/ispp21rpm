﻿using System.Diagnostics;
using System.Threading.Channels;

public class Train
{
    private int number;
    private string city;
    private int seats;

    public Train()
    {
        number = 0;
        city = string.Empty;
        seats = 0;
    }

    public Train(int number, string city, int seats)
    {
        this.number = number;
        this.city = city;
        this.seats = seats;
    }

    public int getNumber()
    {
        return number;
    }
    public string getCity()
    { 
        return city; 
    }
    public int getSeats() 
    {
        return seats; 
    }

    public object this[string index]
    {
        get 
        { 
            switch (index.ToLower())
            {
                case "номер поезда":
                    return number;
                case "место прибытия":
                    return city;
                case "свободные места":
                    return seats;
                default:
                    return null;
            }
        }
    }
    public char this[int index]
    {
        get
        {
            if (index >= 0 && index < city.Length)
            {
                return city[index];
            }
            else
            {
                return '\0';
            }
        }
    }
}
class Program
{
    static void Main()
    {
        Train defaultTrain = new Train();
        Console.WriteLine("По умолчанию");
        DisplayTrainInfo(defaultTrain);

        Train parameterized = new Train(123, "Архангельск", 50);
        Console.WriteLine("\nС параметром");
        DisplayTrainInfo(parameterized);

        //Train train = new Train();
        //train.SetNumber(43);
        //train.SetCity("sada");
        //train.SetSeats(43);
        //Console.WriteLine("\nНомер поезда: " + train["номер поезда"]);
        //Console.WriteLine("Место прибытия: " + train["место прибытия"]);
        //Console.WriteLine("свободные места: " + train["свободные места"]);
        //Console.WriteLine("Не верный индекс: " + train["индекс"]);

        //Console.WriteLine("\n Первый символ пункта назначения" + train[0]);
        //Console.WriteLine("\n Неверный индекс" + train[-1]);
    }
    static void DisplayTrainInfo(Train train)
    {
        Console.WriteLine($"Номер поезда: {train.getNumber()}");
        Console.WriteLine($"Пункт назначения: {train.getCity()}");
        Console.WriteLine($"Свободные места: {train.getSeats()}");
    }
    
}
