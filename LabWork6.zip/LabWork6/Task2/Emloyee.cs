﻿public class Employee
{
    public string fullName;
    public string post;
    public int salary;

    public Employee()
    {
        this.fullName = "Unknown";
        this.post = "Employee";
        this.salary = 0;
    }
    public Employee(string fullname, string post, int salary)
    {
        this.fullName = fullname;
        this.post = post;
        this.salary = salary;
    }
    public object this[string index]
    {
        get
        {
            switch (index)
            {
                case "fullName":
                    return fullName;
                case "post":
                    return post;
                case "salary":
                    return salary;
                default:
                    return null;
            }
        }
    }
    public char this[int index]
    {
        get
        {
            if (index >= 0 && index < fullName.Length)
            {
                return fullName[index];
            }
            else
            {
                return '\0';
            }
        }
    }    
}