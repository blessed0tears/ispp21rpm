﻿public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine(SquareArea(5)); 
        Console.WriteLine(RectangleArea(5, 10)); 

        Console.WriteLine(SquarePerimeter(5));
        Console.WriteLine(RectanglePerimeter(5, 10));
    }
    // Метод для вычисления площади квадрата
    public static double SquareArea(double side)
    {
        return side * side;
    }
    // Метод для вычисления площади прямоугольника
    public static double RectangleArea(double length, double width)
    {
        return length * width;
    }
    // Метод для вычисления периметра квадрата
    public static double SquarePerimeter(double side)
    {
        return 4 * side;
    }
    // Метод для вычисления периметра прямоугольника
    public static double RectanglePerimeter(double length, double width)
    {
        return 2 * (length + width);
    }
}
