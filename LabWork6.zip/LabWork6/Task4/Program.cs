﻿public class Program
{
    public static void Main(string[] args)
    {
        // Тестирование методов
        Console.WriteLine(CalculateRationalFunction(2, 3)); // 1/8 = 0.125
        Console.WriteLine(CalculateRationalFunction(2)); // 1/2 = 0.5
    }
    // Метод для вычисления рациональной функции 1/x^n
    public static double CalculateRationalFunction(double x, int n)
    {
        if (x == 0 || n < 0)
        {
            return -1;
        }

        double result = 1;
        for (int i = 0; i < n; i++)
        {
            result /= x;
        }

        return result;
    }
    // Метод для вычисления функции 1/x
    public static double CalculateRationalFunction(double x)
    {
        if (x == 0)
        {
            return -1;
        }

        return 1 / x;
    }
}
