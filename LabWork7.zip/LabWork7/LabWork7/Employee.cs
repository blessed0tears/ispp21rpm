﻿namespace LabWork7
{
    public class Employee
    {
        public string FullName { get; set; }
        public string Position { get; set; }
        public int Salary { get; set; }

        //перегрузка унарного оператора
        public static Employee operator ++(Employee employee1)
            => new Employee { FullName = employee1.FullName, Position = employee1.Position, Salary = employee1.Salary + 100 };

        //отдельная перегрузка бинарного оператора
        public static Employee operator +(Employee employee1, Employee employee2)
            => new Employee { FullName = employee1.FullName, Position = employee1.Position, Salary = employee1.Salary + employee2.Salary };

        //перегрузка оператор ==
        public static bool operator ==(Employee employee1, Employee employee2)
            => employee1.Salary == employee2.Salary;

        //перегрузка оператор !=
        public static bool operator !=(Employee employee1, Employee employee2)
            => employee1.Salary != employee2.Salary;

        // перегрузка true/false
        public static bool operator true(Employee employee2)
            => employee2.Salary >= 0;

        public static bool operator false(Employee employee2)
            => employee2.Salary < 0;
    }
}
