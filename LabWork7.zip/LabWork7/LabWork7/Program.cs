﻿using System;

namespace LabWork7
{
    public class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee();
            Employee employee2 = new Employee();            
            Employee employee4 = new Employee();

            employee1.Salary = 10787;
            employee2.Salary = 10787;   // +100, emp1 == emp2  = true            
            employee4.Salary = 123;

            Console.WriteLine("Исходное значение: " + employee1.Salary);
            employee1++;
            Console.WriteLine("Значение после изменения: " + employee1.Salary + "\n");

            Employee employee3 = employee1 + employee2;
            Console.WriteLine($"{employee3.Salary} = {employee1.Salary} + {employee2.Salary} \n");          

            Console.WriteLine($"employee1 == employee2: {employee1 == employee2}" + "\n");
            Console.WriteLine($"employee1 != employee2: {employee1 != employee2}" + "\n");
                        
            if (employee4)            
                Console.WriteLine("Зарплата больше или равна 0");
            else
                Console.WriteLine("Зарплата отрицательная");            
        }
    }
}
