﻿namespace LabWork7
{

    internal class Program
    {
        static void Main(string[] args)

        {
            Train train = new Train();
            train.Number = 1;
            train.Seats = 150; ;
            train.Destination = ("Moscow");
            

            Console.WriteLine("Исходные значения: ");
            Console.WriteLine($"Номер: {train.Number}, Город: {train.Destination}, Свободные места: {train.Seats}");
            train++;
            Console.WriteLine("Значения после увелечения: ");
            Console.WriteLine($"Номер: {train.Number}, Город: {train.Destination}, Свободные места: {train.Seats}");
            
            Console.WriteLine("\nИсходные значения: ");
            Console.WriteLine($"Номер: {train.Number}, Город: {train.Destination}, Свободные места: {train.Seats}");
            Console.WriteLine("Значения после увелечения: ");
            Console.WriteLine("Свободные места " + train.Seats);


            if (train)
                Console.WriteLine("Количество сидений >= 0");
            else
                Console.WriteLine("Количество сидений < 0");
        }
    }
}