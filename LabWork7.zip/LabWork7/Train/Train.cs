﻿namespace LabWork7
{
    public class Train
    {
        public int Number { get; set; }
        public string Destination { get; set; }
        public int Seats { get; set; }


        public static Train operator ++(Train train)
            => new() { Seats = train.Seats + 1, Number = train.Number, Destination = train.Destination };

        public static Train operator +(Train train1, Train train2)
            => new() { Seats = train1.Seats + train2.Seats, Number = train1.Number, Destination = train1.Destination };
        
        public static bool operator true(Train train)
            => train.Seats >= 0;

        public static bool operator false(Train train)
           => train.Seats < 0;
    }
}