﻿namespace LabWork8
{
    public class Employee
    {
        public string Fullname { get; set; }
        public string Post { get; set; }
        public double Salary { get; set; }

        public override string ToString()
            => $"ФИО: {Fullname}, Должность: {Post}, Зарплата: {Salary}";
    }
}
