﻿namespace LabWork8
{
    public class Program
    {
        static void Main() 
        {
            Employee employee = new Employee
            {
                Fullname = "Щербакова Софья Лукинична",
                Post = "Кассир",
                Salary = 13050                
            };

            Console.WriteLine(employee.ToString());
            Console.WriteLine(employee);
        }     
    }
}
