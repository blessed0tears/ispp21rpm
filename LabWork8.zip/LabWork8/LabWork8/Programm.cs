﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork8
{
    internal class Programm
    {
        static void Main(string[] args /*Circle circle*/)
        {
            Train train1 = new Train(1, "Moscow", 200);
            Train train2 = new Train(2, "SPB", 150);
            Train train3 = new Train(1, "Moscow", 200);
            // явно
            Console.WriteLine(train1.ToString());
            Console.WriteLine(train2.ToString());
            // неявно
            Console.WriteLine(train1);
            Console.WriteLine(train2);

            Console.WriteLine(train1.Equals(train2));
            Console.WriteLine(train1.Equals(train3));

            /*Circle circle = new Circle(5);
            Circle.ShapeInformation();*/
        }
    }
}
