﻿using System.Threading.Channels;

namespace LabWork8;
class Train
{
    public int Number {  get; set; }
    public string Destination { get; set; }
    public int Seats { get; set; }

    public Train(int number, string destination, int seats)
    {
        Number = number;
        Destination = destination;
        Seats = seats;
    }
    public override string ToString()
    {
        return $"Номер поезда {Number} направляется в {Destination} с {Seats} свободными местами";
    }
    public override bool Equals(object? obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false; 
        }
        Train other = (Train)obj;
        return Number == other.Number && Destination == other.Destination && Seats == other.Seats ;
    }   
}
/*abstract class Figure
{
    public abstract double GetSquare();
    public abstract double GetPerimeter();
    public abstract void ShapeInformation();
    public abstract string Property { get; }
}
class Circle : Figure
{
    public double Radius;
    public Circle(double radius)
    {
       double Radius = radius;
    }
    public override double GetSquare()
    {
        return Math.PI * Radius * Radius;
    }
    public override double GetPerimeter()
    {
        return 2 * Math.PI * Radius;
    }
    public override void ShapeInformation()
    {
        
        Console.WriteLine($"Фигура: {Property}");
        Console.WriteLine($"Радиус: {Radius}");
        Console.WriteLine($"Площадь: {GetSquare}");
        Console.WriteLine($"Периметр: {GetPerimeter}");
    }
    public override string Property => "Круг";
}
*/
