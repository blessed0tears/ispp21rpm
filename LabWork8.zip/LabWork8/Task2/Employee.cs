﻿namespace LabWork8
{
    public class Employee
    {
        public string Fullname { get; set; }
        public string Post { get; set; }
        public double Salary { get; set; }

        public override bool Equals(object? obj)
        {
            if(obj == null || GetType() != obj.GetType())
                return false;

            Employee other = (Employee)obj;
            return Fullname == other.Fullname && Post == other.Post && Salary == other.Salary;
        }
    }
}
