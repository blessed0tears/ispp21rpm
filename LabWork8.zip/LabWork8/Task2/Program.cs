﻿namespace LabWork8
{
    public class Program
    {
        static void Main()
        {
            Employee employee1 = new Employee
            {
                Fullname = "Щербакова Софья Лукинична",
                Post = "Кассир",
                Salary = 13050
            };
            Employee employee2 = new Employee
            {
                Fullname = "Руднева Стефания Всеволодовна",
                Post = "Директор",
                Salary = 160225
            };
            Console.WriteLine(employee1.Equals(employee2));
        }
    }
}
