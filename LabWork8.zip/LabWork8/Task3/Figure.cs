﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    public abstract class Figure
    {
        public abstract double Area { get; }
        public abstract double Perimeter { get; }
        public abstract string Name { get; }

        public abstract void OutputInformation();
    }

    public class Square : Figure
    {
        public double side { get; set; }

        public Square(double side)
        {
            this.side = side;
        }

        public override double Area => side * side;
        public override double Perimeter => 4 * side;
        public override string Name => "Квадрат";

        public override void OutputInformation()
        {
            Console.WriteLine($"Название: {Name}, Сторона: {side}, Площадь: {Area}, Периметр: {Perimeter}");
        }
    }

    public class Rectangle : Figure
    {
        public double length { get; set; }
        public double height { get; set; }

        public Rectangle(double length, double height)
        {
            this.length = length;
            this.height = height;
        }

        public override double Area => length * height;
        public override double Perimeter => 2 * (height + length);
        public override string Name => "Прямоугольник";

        public override void OutputInformation()
        {
            Console.WriteLine($"Название: {Name}, Длина: {length}, Высота: {height}, Площадь: {Area}, Периметр: {Perimeter}");
        }
    }
}
