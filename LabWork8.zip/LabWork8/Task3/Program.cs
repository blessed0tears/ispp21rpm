﻿using Task3;

namespace LabWork8
{
    public class Employee
    {
        static void Main(string[] args)
        {
            Square square = new(5);
            square.OutputInformation();
            Rectangle rectangle = new(5,4);
            rectangle.OutputInformation();
        }
    }
}