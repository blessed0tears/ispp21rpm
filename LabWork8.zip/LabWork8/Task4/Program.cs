﻿namespace Task4
{
    public class Program
    {
        static void Main(string[] args)
        {
            ExpandedRandom random = new ExpandedRandom();
            int[] randomInt = random.GetRandomInt(10);

            foreach (var numbers in randomInt)
            {
                Console.WriteLine(numbers);
            }
        }
    }
}