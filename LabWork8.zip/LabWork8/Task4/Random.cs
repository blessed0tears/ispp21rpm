﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    public class ExpandedRandom : Random
    {
        public int[] GetRandomInt(int count)
        {
            int[] result = new int[count];
            for (int i = 0; i < count; i++)
            {
                result[i] = Next();
            }
            return result;
        }
    }
}
