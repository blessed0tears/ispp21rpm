﻿using LabWork9;

public class Employee
{
    public string FullName { get; set; }
    public string Position { get; set; }
    public decimal Salary { get; set; }

    public void PrintEmployee()
    {
        Console.WriteLine($"ФИО: {FullName}, Должность: {Position}, Зарплата: {Salary}");
    }
    
}
