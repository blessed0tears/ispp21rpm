﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork9
{
    internal class Program
    {
        static void Main(string[] args) 
        {
            Circle circle = new Circle(5);
            circle.Print();
            Train train = new Train(1, "Moscow", 200);
            train.Print();
        }
    }
}
