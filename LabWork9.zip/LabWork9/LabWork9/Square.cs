﻿namespace LabWork9
{
    public class Square
    {
        public double Side { get; set; }

        public void PrintSquare()
        {
            Console.WriteLine($"Сторона: {Side}");
        }
    }

}
