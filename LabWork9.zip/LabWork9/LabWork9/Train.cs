﻿namespace LabWork9;
interface IPrinter
{
    void Print();
}

class Circle : IPrinter
{
    public double Radius; 
    public Circle (double radius)
    {
        Radius = radius;
    }
    public void Print()
    {
        Console.WriteLine($"Круг с радиусом: {Radius}");
    }
}

class Train : IPrinter
{
    public int Number;
    public string Destination;
    public int Seats;

    public Train(int number, string destination, int seats)
    {
        Number = number;
        Destination = destination;
        Seats = seats;
    }

    public void Print() 
    {
        Console.WriteLine($"Поезд №{Number} направляется в {Destination} с {Seats} свободными местами");
    }
}

















