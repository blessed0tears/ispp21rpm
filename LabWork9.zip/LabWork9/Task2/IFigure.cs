﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork9
{
    public interface IFigure
    {
        double GetArea();
        double GetPerimeter();
        void PrintInfo();
        string Name { get; }
    }

}
