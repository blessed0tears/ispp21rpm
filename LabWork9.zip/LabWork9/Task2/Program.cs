﻿using LabWork9;

public class Program
{
    public static void Main(string[] args)
    {
        Square square = new Square { Side = 5 };
        square.PrintInfo();
        Console.WriteLine($"Название фигуры: {square.Name}");
    }
}