﻿namespace LabWork9
{
    public class Square : IFigure, IPrinter
    {
        public double Side { get; set; }

        public double GetArea()
        {
            return Side * Side;
        }
        public double GetPerimeter()
        {
            return 4 * Side;
        }
        public void PrintInfo()
        {
            Console.WriteLine($"Название: {Name}, Сторона: {Side}, Площадь: {GetArea()}, Периметр: {GetPerimeter()}");
        }
        public string Name
        {
            get { return "Квадрат"; }
        }
        public void Print()
        {
            PrintInfo();
        }
    }
}
