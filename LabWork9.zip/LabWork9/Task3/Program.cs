﻿namespace LabWork9
{
    class Program
    {
        static void Main(string[] args)
        {
            Square square = new Square { Side = 7 };
            square.PrintInfo();
        }
    }
}

