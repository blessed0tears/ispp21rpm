﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork9
{
    public class Square : IFigure, IPrinter
    {
        public double Side { get; set; }
        public string Name => "Квадрат";

        public double GetArea()
        {
            return Side * Side;
        }

        public double GetPerimeter()
        {
            return 4 * Side;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Квадрат: Сторона = {Side}, Площадь = {GetArea()}, Периметр = {GetPerimeter()}");
        }

        public void PrintSquare()
        {
            PrintInfo();
        }
    }

}
