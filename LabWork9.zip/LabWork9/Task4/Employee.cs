﻿using LabWork9;

public class Employee : IPrinter
{
    public string FullName { get; set; }
    public string Position { get; set; }
    public decimal Salary { get; set; }

    public void Print()
    {
        Console.WriteLine($"ФИО: {FullName}, Должность: {Position}, Зарплата: {Salary}");
    }
    
}
