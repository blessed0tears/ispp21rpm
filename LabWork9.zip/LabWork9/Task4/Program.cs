﻿using LabWork9;
class Program
{
    static void Main(string[] args)
    {
        Employee employee = new Employee { FullName = "Казанцева Анна Кирилловна", Position = "Инженер", Salary = 50000 };
        employee.Print();

        Square square = new Square { Side = 5 };
        square.PrintInfo();

        IPrinter[] printers = new IPrinter[]
        {
            new Employee { FullName = "Казанцева Анна Кирилловна", Position = "Инженер", Salary = 50000 },
            new Employee { FullName = "Казанцев Кирилл Кириллович", Position = "Инженер", Salary = 60000 },
            new Square { Side = 5 },
            new Square { Side = 10 }
        };

        foreach (var p in printers)
        {
            p.Print();
            if (p is IFigure figure)
            {
                Console.WriteLine($"Название фигуры: {figure.Name}");
            }
        }
    }
}