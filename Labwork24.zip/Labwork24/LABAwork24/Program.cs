﻿class UserRegistration
{
    private string login;
    private string password;

    private bool IsCorrectUserData(string inputLogin, string inputPassword, string confirmPassword)
    {
        bool isLoginCorrect = !string.IsNullOrEmpty(inputLogin);
        bool isPasswordCorrect = !string.IsNullOrEmpty(inputPassword);
        bool isConfirmCorrect = inputPassword == confirmPassword;

        return isLoginCorrect && isPasswordCorrect && isConfirmCorrect;
    }

    static void Main()
    {
        UserRegistration user = new UserRegistration();

        Console.WriteLine("Enter your login: ");
        string inputLogin = Console.ReadLine();

        Console.WriteLine("Enter your password: ");
        string inputPassword = Console.ReadLine();

        Console.WriteLine("Confirm your password: ");
        string confirmPassword = Console.ReadLine();

        if (user.IsCorrectUserData(inputLogin, inputPassword, confirmPassword))
        {
            user.login = inputLogin;
            user.password = inputPassword;
            Console.WriteLine("Registration successful! Welcome, " + user.login + "!");
        }
        else
        {
            Console.WriteLine("Registration failed. Please check your input data.");
        }
    }
}


