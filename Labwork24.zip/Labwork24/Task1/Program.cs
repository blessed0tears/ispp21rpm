﻿using System;

namespace UserRegistrationApp
{
    class Program
    {
        static void Main(string[] args)
        {            
            User user = new User();

            Console.Write("Введите логин: ");
            string login = Console.ReadLine();

            Console.Write("Введите пароль: ");
            string password = Console.ReadLine();

            Console.Write("Подтвердите пароль: ");
            string confirmPassword = Console.ReadLine();

            if (user.IsCorrectUserData(login, password, confirmPassword))
            {
                user.Login = login;
                user.Password = password;
                Console.WriteLine("Регистрация успешна.");
            }
            else
            {
                Console.WriteLine("Регистрация не удалась. Проверьте введенные данные.");
            }
        }
    }
}
