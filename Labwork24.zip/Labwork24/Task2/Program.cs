﻿using System;

namespace UserRegistrationApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создаем экземпляр класса User
            User user = new User();

            // Ввод данных
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();

            Console.Write("Введите пароль: ");
            string password = Console.ReadLine();

            Console.Write("Подтвердите пароль: ");
            string confirmPassword = Console.ReadLine();

            // Проверка введенных данных
            if (user.IsCorrectUserData(login, password, confirmPassword))
            {
                // Присвоение значений полям
                user.Login = login;
                user.Password = password;
                Console.WriteLine("Регистрация успешна.");
            }
            else
            {
                Console.WriteLine("Регистрация не удалась. Проверьте введенные данные.");
            }
        }
    }
}
