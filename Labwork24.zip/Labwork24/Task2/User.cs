﻿namespace UserRegistrationApp
{
    class User
    {
        // Закрытые поля для хранения логина и пароля
        private string login;
        private string password;

        // Свойства для доступа к логину и паролю
        public string Login
        {
            get { return login; }
            set { login = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        // Метод для проверки корректности введенных данных
        public bool IsCorrectUserData(string login, string password, string confirmPassword)
        {
            // Извлечение переменных
            bool isLoginCorrect = !string.IsNullOrEmpty(login);
            bool isPasswordCorrect = !string.IsNullOrEmpty(password);
            bool isConfirmCorrect = password == confirmPassword;

            // Проверка всех условий
            return isLoginCorrect && isPasswordCorrect && isConfirmCorrect;
        }
    }
}
