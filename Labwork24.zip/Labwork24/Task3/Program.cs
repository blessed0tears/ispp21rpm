﻿public class DateUtils
{
    private static int[] DaysInMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    public int GetDaysCount(int month, int year)
    {
        if (month < 1 || month > 12)
        {
            return -1;
        }

        int days = DaysInMonth[month - 1];

        if (month == 2 && IsLeapYear(year))
        {
            days++;
        }
        return days;
    }

    private bool IsLeapYear(int year)
    {
        return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0));
    }

    static void Main()
    {
        Console.WriteLine(DateUtils.DaysInMonth);
    }
}

