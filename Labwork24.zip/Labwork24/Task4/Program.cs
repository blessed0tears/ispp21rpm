﻿public class DateUtils
{
    private static readonly int[] DaysInMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    public int GetDaysCount(int month, int year)
    {
        if (month < 1 || month > 12)
        {
            throw new ArgumentException("Неправильный номер месяца");
        }

        int days = DaysInMonth[month - 1];

        if (month == 2 && IsLeapYear(year))
        {
            days++;
        }

        return days;
    }

    private bool IsLeapYear(int year)
    {
        return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0));
    }
}
