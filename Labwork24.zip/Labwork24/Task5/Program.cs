﻿using System;

namespace ShapeAreaApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите тип фигуры (1 - Прямоугольник, 2 - Круг, 3 - Кольцо): ");
            int shapeType = int.Parse(Console.ReadLine());

            Shape shape;

            switch (shapeType)
            {
                case 1:
                    Console.Write("Введите длину: ");
                    double length = double.Parse(Console.ReadLine());
                    Console.Write("Введите ширину: ");
                    double width = double.Parse(Console.ReadLine());
                    shape = new Rectangle(length, width);
                    break;
                case 2:
                    Console.Write("Введите радиус: ");
                    double radius = double.Parse(Console.ReadLine());
                    shape = new Circle(radius);
                    break;
                case 3:
                    Console.Write("Введите внешний радиус: ");
                    double outerRadius = double.Parse(Console.ReadLine());
                    Console.Write("Введите внутренний радиус: ");
                    double innerRadius = double.Parse(Console.ReadLine());
                    shape = new Ring(outerRadius, innerRadius);
                    break;
                default:
                    throw new ArgumentException("Неправильный тип фигуры");
            }

            Console.WriteLine($"Площадь фигуры: {shape.GetArea()}");
        }
    }
}
