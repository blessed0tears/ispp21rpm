﻿namespace ShapeAreaApp
{
    class Ring : Shape
    {
        public double OuterRadius { get; set; }
        public double InnerRadius { get; set; }

        public Ring(double outerRadius, double innerRadius)
        {
            OuterRadius = outerRadius;
            InnerRadius = innerRadius;
        }

        public override double GetArea()
        {
            double outerArea = Math.PI * OuterRadius * OuterRadius;
            double innerArea = Math.PI * InnerRadius * InnerRadius;
            return outerArea - innerArea;
        }
    }
}
